﻿namespace WebPoker.PlayersRepository;

using WebPoker.Repository;

public class PlayerRepository
{
   
}